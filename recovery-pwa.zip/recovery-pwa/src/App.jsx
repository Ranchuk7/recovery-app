import { useState, useEffect, useCallback } from "react";

// ── CONSTANTS ──────────────────────────────────────────────────────────────────
const injuryDate = new Date("2026-01-09");
const today = new Date();
const daysSinceInjury = Math.floor((today - injuryDate) / (1000 * 60 * 60 * 24));
const weeksSinceInjury = Math.floor(daysSinceInjury / 7) + 1;
const swedenDate = new Date("2026-08-07");
const totalDays = Math.floor((swedenDate - injuryDate) / (1000 * 60 * 60 * 24));
const progressPercent = Math.min(100, Math.round((daysSinceInjury / totalDays) * 100));

function daysUntil(dateStr) {
  return Math.max(0, Math.floor((new Date(dateStr) - today) / (1000 * 60 * 60 * 24)));
}

const PHASE_COLORS = ["#0a84ff", "#34c759", "#bf5af2", "#ff453a"];

const MILESTONES = [
  { date: "30.03", label: "Rückkehr Arbeit", color: "#34c759", fullDate: "2026-03-30" },
  { date: "01.05", label: "Gilis Hochzeit", color: "#bf5af2", fullDate: "2026-05-01" },
  { date: "01.07", label: "Fußball", color: "#ff453a", fullDate: "2026-07-01" },
  { date: "07.08", label: "Schweden 🚴", color: "#ffd60a", fullDate: "2026-08-07" },
];

// ── CLINICAL NOTES PER PHASE ─────────────────────────────────────────────────
// Sequestered L5/S1, S1 root compression, no symptoms at rest, no claudication
// Pure motor deficit: gastroc/soleus weakness → antalgic gait
// Safe: extension, flexion, neutral spine loading
// Protocol: aggressive neurodynamic mobilization + progressive heel raise overload

const PHASES = [
  {
    id: 1,
    name: "Stabilisierung & Hypertrophie",
    dateRange: "Jan – März",
    startDate: "2026-01-09",
    endDate: "2026-03-30",
    status: "current",
    color: "#0a84ff",
    clinicalNote: "Sequestered S1-Kompression. Kein axialer Druck. Neurodynamik-Mobilisation aktiv. Motor-Retraining Gastroc/Soleus priorisiert.",
    rationale: [
      "Sequestered fragment → kein contained disc → Resorption durch Makrophagen-Aktivität. Extension und Flexion neutral → sicheres Bewegungsprofil.",
      "Kein Ruhe-Schmerz, keine Claudicatio → aggressivere Belastung möglich als Standard-Protokoll.",
      "S1-Motor-Deficit: Gastroc (S1/S2) + Soleus (S1) → progressive Heel-Raise-Überladung ist KPI #1.",
      "Sciatic Nerve Flossing: sicher bei mechanischem SLR-Endgefühl ohne zentrale Dura-Irritation.",
    ],
    kpis: [
      { label: "SLR", current: "50°", target: "70°", unit: "°" },
      { label: "Heel Raise links", current: "3–4 Wdh. bis Versagen", target: "15 Wdh. volle Höhe", unit: "" },
      { label: "Gangbild", current: "Leichtes Hinken", target: "Symmetrisch", unit: "" },
      { label: "Tagesschritte", current: "~3.000–8.000", target: "8.000 ohne Nachschmerz", unit: "" },
    ],
    exercises: {
      home: [
        {
          id: "nerve-floss", name: "Sciatic Nerve Flossing", sets: 3, reps: 10,
          tag: "Neurodynamik · KPI", isKPI: true, priority: "HIGH",
          youtube: "https://www.youtube.com/watch?v=4-gMLRibbT0",
          clinical: "Sicher: mechanisches SLR-Endgefühl ohne zentrale Dura-Irritation. Mobilisiert Nervenscheide, reduziert neuralen Tonus.",
          cues: [
            "Sitzen, Knie gestreckt, Knöchel dorsiflektiert → Kopf nach vorne neigen",
            "Dann: Knie beugen, Kopf aufrichten — rhythmisch",
            "Kein Schmerz — nur Zug. Bei Ausstrahlung sofort stoppen",
          ],
          progression: "Woche 8–10: sitzend. Woche 11+: stehend (Tensioner)"
        },
        {
          id: "heel-raise-seated-prog", name: "Heel Raise — Sitzen (Progressiv)", sets: 5, reps: "bis Versagen",
          tag: "KPI #1 · S1-Motor", isKPI: true, priority: "HIGH",
          youtube: "https://www.youtube.com/watch?v=LV6cJUMNhJY",
          clinical: "Gastroc/Soleus: reine motorische Schwäche S1. Ziel: Muskelerschöpfung — nicht Schmerz. Progression: bilateral → unilateral → belastet.",
          cues: [
            "Beide Beine: maximale Wiederholungen bis Muskelversagen",
            "Dann links allein: Wiederholungen notieren",
            "2 Sek. hoch, 3 Sek. runter — kein Schwung",
            "Progressive Overload: Woche 8–9 bilateral, ab Woche 10 links allein",
          ],
          progression: "Woche 10: links unilateral. Woche 12: mit Gewichtsweste/Rucksack"
        },
        {
          id: "dead-bug-adv", name: "Dead Bug (fortgeschritten)", sets: 3, reps: 10,
          tag: "Core · Anti-Extension", priority: "MEDIUM",
          youtube: "https://www.youtube.com/watch?v=4XLEnwUr1d8",
          clinical: "Anti-Extension Core-Stabilität. Schützt L5/S1 bei axialer Belastung. Grundlage für alle funktionellen Bewegungen.",
          cues: [
            "Lendenwirbelsäule flach — kontrollieren mit Hand",
            "Ausatmen 5 Sek. beim Senken",
            "Fortgeschritten: Widerstandsband an Armen",
          ],
          progression: "Mit Band an Armen (Woche 10+)"
        },
        {
          id: "single-leg-balance", name: "Einbeinstand + Perturbation", sets: 3, reps: "30 Sek.",
          tag: "Propriozeption · Gangbild", priority: "HIGH",
          youtube: "https://www.youtube.com/watch?v=3xNXBGM7ubs",
          clinical: "Gastroc-Schwäche → gestörte Propriozeption Sprunggelenk/Fuß links → Hinken. Einbeinstand trainiert neuromuskuläre Kontrolle direkt.",
          cues: [
            "Links allein stehen, leicht gebeugte Knie",
            "Partner schubst leicht — oder: Augen schließen",
            "Auf weicher Unterlage (Kissen) = höhere Intensität",
            "Kein Schmerz im Rücken",
          ],
          progression: "Woche 10: instabile Unterlage. Woche 12: mit Wurfball"
        },
        {
          id: "clam-shell-prog", name: "Clam Shell (progressiv)", sets: 4, reps: 15,
          tag: "Glute Med · Gangbild", priority: "MEDIUM",
          youtube: "https://www.youtube.com/watch?v=SL_Q874WRNE",
          clinical: "Gluteus medius-Schwäche → Trendelenburg-Gangbild. Zusammen mit Gastroc-Deficit Hauptursache des Hinkens.",
          cues: [
            "Widerstandsband über Knie",
            "Becken absolut stabil",
            "3 Sek. in Endposition halten",
          ],
          progression: "Stärkeres Band alle 2 Wochen"
        },
        {
          id: "bird-dog-adv", name: "Bird Dog (fortgeschritten)", sets: 3, reps: 12,
          tag: "Lumbal-Stabilität", priority: "MEDIUM",
          youtube: "https://www.youtube.com/watch?v=wiFNA3sqjCA",
          clinical: "Multifidus-Aktivierung L5/S1-Segment. Kontralaterale Stabilität — Basis für manuelle Therapie-Belastungen.",
          cues: [
            "5 Sek. halten in Endposition",
            "Kein Beckenkippen — Wasserwaage vorstellen",
            "Fortgeschritten: Widerstandsband an Fuß",
          ],
          progression: "Mit Band ab Woche 10"
        },
        {
          id: "incline-pushup-prog", name: "Incline Push-Up → Floor Push-Up", sets: 4, reps: 12,
          tag: "Brust · Hypertrophie", priority: "LOW",
          youtube: "https://www.youtube.com/watch?v=pkbWJaHSMXE",
          clinical: "Oberkörper-Hypertrophie ohne axiale Wirbelsäulenbelastung. Incline → flach progressiv.",
          cues: ["Körper gerade", "3 Sek. exzentrisch", "Bis Muskelversagen"],
          progression: "Woche 10: flacher Boden. Woche 12: Füße erhöht"
        },
        {
          id: "floor-press-prog", name: "Floor Press (Kurzhanteln, progressiv)", sets: 4, reps: 10,
          tag: "Brust · Hypertrophie", priority: "LOW",
          youtube: "https://www.youtube.com/watch?v=uUGDRwge4F8",
          clinical: "Sichere Bench-Alternative. Boden limitiert ROM, schützt Schulter und Wirbelsäule.",
          cues: ["Ellenbogen 45°", "Rücken flach", "Gewicht wöchentlich erhöhen"],
          progression: "+1–2 kg alle 2 Wochen"
        },
        {
          id: "seated-row-band", name: "Seated Row (Band, progressiv)", sets: 4, reps: 12,
          tag: "Rücken · Hypertrophie", priority: "LOW",
          youtube: "https://www.youtube.com/watch?v=xQNrFHEMhI4",
          clinical: "Rhomboid/Trapez/Lat. Antagonist zu Push-Übungen. Stärkeres Band = linearer Fortschritt.",
          cues: ["Aufrechter Rücken", "Schulterblätter zusammen", "2 Sek. halten"],
          progression: "Stärkeres Band alle 2 Wochen"
        },
      ],
      gym: [
        {
          id: "nerve-floss-g", name: "Sciatic Nerve Flossing", sets: 3, reps: 10,
          tag: "Neurodynamik · KPI", isKPI: true, priority: "HIGH",
          youtube: "https://www.youtube.com/watch?v=4-gMLRibbT0",
          clinical: "Identisch wie Heimversion. Vor dem Training durchführen.",
          cues: ["Sitzen auf Bank", "Knie strecken + Kopf vorneigen", "Knie beugen + Kopf aufrichten", "Kein Schmerz — nur Zug"],
          progression: "Woche 11+: stehend (Tensioner)"
        },
        {
          id: "calf-raise-machine", name: "Calf Raise (Maschine, sitzend/stehend)", sets: 6, reps: "bis Versagen",
          tag: "KPI #1 · S1-Motor", isKPI: true, priority: "HIGH",
          youtube: "https://www.youtube.com/watch?v=LV6cJUMNhJY",
          clinical: "Maschine erlaubt genaues Tracking + progressive Overload. Wöchentliche Steigerung möglich.",
          cues: [
            "Bilateral zuerst — dann links unilateral",
            "Voller ROM: Ferse ganz unten, Zehen ganz oben",
            "Gewicht wöchentlich +2,5 kg wenn 15 Wdh. erreicht",
            "Links vs. Rechts dokumentieren",
          ],
          progression: "Ab 15 Wdh.: Gewicht erhöhen. Ab Woche 12: nur links mit Gewicht"
        },
        {
          id: "single-leg-balance-g", name: "BOSU Einbeinstand", sets: 3, reps: "45 Sek.",
          tag: "Propriozeption · Gangbild", priority: "HIGH",
          youtube: "https://www.youtube.com/watch?v=3xNXBGM7ubs",
          clinical: "BOSU = maximale propriozeptive Herausforderung. Schnellste Normalisierung des Gangbilds.",
          cues: ["Links auf BOSU-Halbkugel", "Augen offen → zu", "Leichte Kniebiegung", "Kein Rückenschmerz"],
          progression: "Woche 12: mit Wurfball + Augen zu"
        },
        {
          id: "leg-press-g", name: "Leg Press (Maschine)", sets: 4, reps: 12,
          tag: "Beine · Hypertrophie", priority: "MEDIUM",
          youtube: "https://www.youtube.com/watch?v=IZxyjW7MPJQ",
          clinical: "Kein axialer Wirbelsäulendruck. Quadrizeps/Glute-Aufbau. Symmetrie links/rechts beobachten.",
          cues: ["Rücken flach", "90° Kniewinkel", "Nicht durchstrecken oben"],
          progression: "+5 kg alle 2 Wochen"
        },
        {
          id: "lat-pulldown-g", name: "Lat Pulldown (Kabel)", sets: 4, reps: 12,
          tag: "Rücken · Hypertrophie", priority: "LOW",
          youtube: "https://www.youtube.com/watch?v=CAwf7n6Luuc",
          clinical: "Lat/Rhomboid-Aufbau ohne Axialbelastung. Sitzen an Maschine ist sicherer als stehend.",
          cues: ["Schultern runter", "Mit Ellenbogen ziehen", "Voller ROM"],
          progression: "+2,5 kg alle 2 Wochen"
        },
        {
          id: "cable-row-g", name: "Cable Row (Maschine)", sets: 4, reps: 12,
          tag: "Rücken · Hypertrophie", priority: "LOW",
          youtube: "https://www.youtube.com/watch?v=GZbfZ033f74",
          clinical: "Horizontaler Zug. Mittlerer/oberer Rücken. Sitzen = Wirbelsäule geschützt.",
          cues: ["Aufrechter Rücken", "Ellenbogen nah", "2 Sek. Kontraktion"],
          progression: "+2,5 kg alle 2 Wochen"
        },
        {
          id: "chest-press-g", name: "Chest Press (Maschine)", sets: 4, reps: 10,
          tag: "Brust · Hypertrophie", priority: "LOW",
          youtube: "https://www.youtube.com/watch?v=xUm0BiZCX_I",
          clinical: "Sicherer als Freihantel-Bench. Rücken gestützt, kein axiales Risiko.",
          cues: ["Rücken am Polster", "Kontrolliert", "Bis Muskelversagen"],
          progression: "+2,5 kg alle 2 Wochen"
        },
      ],
    },
  },
  {
    id: 2,
    name: "Rückkehr zur Arbeit",
    dateRange: "März 2026",
    startDate: "2026-03-01",
    endDate: "2026-03-30",
    status: "upcoming",
    color: "#34c759",
    milestone: "30.03.2026",
    milestoneLabel: "Rückkehr als Physiotherapeut",
    clinicalNote: "Geschlossene kinetische Kette. Hip Hinge-Muster für Hebe-Techniken. Stehausdauer systematisch aufbauen.",
    rationale: [
      "Physiotherapeut-Belastungen: Stehen 45+ Min., manuelle Therapie, Heben 15 kg → gezielt trainieren.",
      "SLR sollte 70°+ erreicht haben → neurodynamische Belastung erhöhbar.",
      "Heel Raise links muss stehend funktionieren → Gangbild normalisiert.",
    ],
    kpis: [
      { label: "SLR", current: "70°", target: "80°+" },
      { label: "Heel Raise links stehend", current: "10 Wdh.", target: "20 Wdh. unilateral" },
      { label: "Stehausdauer", current: "—", target: "45 Min. schmerzfrei" },
      { label: "Heben", current: "5 kg", target: "15 kg in Technik" },
    ],
    exercises: {
      home: [
        { id: "sciatic-tensioner", name: "Sciatic Nerve Tensioner (stehend)", sets: 3, reps: 10, tag: "Neurodynamik", isKPI: true, priority: "HIGH", youtube: "https://www.youtube.com/watch?v=4-gMLRibbT0", clinical: "Steigerung vom Flossing. Tensioner = mehr mechanische Spannung auf Nervenwurzel. Nur wenn SLR > 70°.", cues: ["Stehend, Knie strecken + Fuß dorsiflektieren + Kopf vorneigen", "Halten 2 Sek., lösen", "Kein Schmerz — nur Zug"], progression: "Nur wenn SLR >70°" },
        { id: "hr-unilateral", name: "Heel Raise links — Unilateral", sets: 5, reps: "bis Versagen", tag: "KPI · S1", isKPI: true, priority: "HIGH", youtube: "https://www.youtube.com/watch?v=LV6cJUMNhJY", clinical: "Meilenstein: links allein. Wenn 15 Wdh. erreicht → Gewicht (Rucksack). KPI für Rückkehr zur Arbeit.", cues: ["Links allein", "Wand zum Abstützen erlaubt", "Wdh. wöchentlich notieren", "Bei 15 Wdh.: Rucksack mit 5 kg"], progression: "15 Wdh. → +5 kg Rucksack" },
        { id: "goblet-squat-h", name: "Goblet Squat (Kettlebell)", sets: 4, reps: 10, tag: "Geschlossen", priority: "MEDIUM", youtube: "https://www.youtube.com/watch?v=MeIiIdhvXT4", clinical: "Erster Übergang in geschlossene kinetische Kette. Anteriore Last reduziert L5/S1-Scherkraft.", cues: ["Fersen am Boden", "Knie über Zehen", "KB nah am Körper"], progression: "Gewicht alle 2 Wochen erhöhen" },
        { id: "kb-rdl", name: "KB Romanian Deadlift", sets: 4, reps: 8, tag: "KPI · Hip Hinge", isKPI: true, priority: "HIGH", youtube: "https://www.youtube.com/watch?v=op9kVnSso6Q", clinical: "Hip-Hinge-Muster = Basis für sicheres Heben im Beruf. Posterior Chain. Keine Flexion der LWS.", cues: ["Hip Hinge — Rücken gerade bleibt", "KB an Unterschenkel entlang", "Gesäß hinten → Gesäß anspannen oben", "Nie mit rundem Rücken"], progression: "+2 kg alle 2 Wochen" },
        { id: "pallof-h2", name: "Pallof Press (Band)", sets: 3, reps: 12, tag: "Core Anti-Rotation", priority: "MEDIUM", youtube: "https://www.youtube.com/watch?v=AH_QZLm_0-s", clinical: "Anti-Rotation = Schutz bei manueller Therapie mit Drehbewegungen.", cues: ["Becken absolut stabil", "Ausatmen beim Drücken", "Beide Seiten gleich"], progression: "Stärkeres Band" },
      ],
      gym: [
        { id: "tensioner-g", name: "Sciatic Nerve Tensioner", sets: 3, reps: 10, tag: "Neurodynamik", isKPI: true, priority: "HIGH", youtube: "https://www.youtube.com/watch?v=4-gMLRibbT0", clinical: "Nur wenn SLR >70°. Steigerung vom Flossing.", cues: ["Stehend auf Bank-Rand", "Knie strecken + Kopf neigen", "Kein Schmerz"], progression: "Nur bei SLR >70°" },
        { id: "calf-machine-unilateral", name: "Calf Raise Maschine — Links allein", sets: 5, reps: "bis Versagen", tag: "KPI · S1", isKPI: true, priority: "HIGH", youtube: "https://www.youtube.com/watch?v=LV6cJUMNhJY", clinical: "Unilateral auf Maschine = präzises Tracking. Symmetrie zu rechts ist das Ziel.", cues: ["Nur links", "Voller ROM", "Gewicht bei 15 Wdh. erhöhen", "Links vs. Rechts vergleichen"], progression: "+2,5 kg wenn 15 Wdh. erreicht" },
        { id: "trap-bar-dl-g", name: "Trap Bar Deadlift", sets: 4, reps: 6, tag: "KPI · Hip Hinge", isKPI: true, priority: "HIGH", youtube: "https://www.youtube.com/watch?v=8pIE7A3MfJA", clinical: "Sicherster Deadlift für LWS-Patienten. Vertikale Kraftlinie. Optimale Hebe-Technik für Beruf.", cues: ["Aufrechter Oberkörper", "Hüfte tief zu Beginn", "Kraft vom Boden mit beiden Beinen", "Gesäß anspannen in Endposition"], progression: "+5 kg alle 2 Wochen" },
        { id: "step-up-weighted", name: "Step Up (mit Gewicht)", sets: 3, reps: 10, tag: "Funktionell", priority: "MEDIUM", youtube: "https://www.youtube.com/watch?v=dQqApCGd5Ss", clinical: "Stufenhöhe 30 cm + Kurzhanteln. Unilaterale Kraft + Propriozeption.", cues: ["Kraft vom Standbein", "Hanteln seitlich", "Symmetrisch links/rechts"], progression: "+2 kg alle 2 Wochen" },
        { id: "leg-press-g2", name: "Leg Press (Maschine)", sets: 4, reps: 10, tag: "Beine", priority: "MEDIUM", youtube: "https://www.youtube.com/watch?v=IZxyjW7MPJQ", clinical: "Quadrizeps-Aufbau für Stehausdauer.", cues: ["Rücken flach", "90°", "Nicht durchstrecken"], progression: "+5 kg alle 2 Wochen" },
      ],
    },
  },
  {
    id: 3,
    name: "Volle Hypertrophie",
    dateRange: "April – Mai 2026",
    startDate: "2026-04-01",
    endDate: "2026-05-01",
    status: "upcoming",
    color: "#bf5af2",
    milestone: "01.05.2026",
    milestoneLabel: "Gilis Hochzeit",
    clinicalNote: "Freie axiale Belastung wenn schmerzfrei. Hohe Intensität. Vegane Ernährung kalorienreich.",
    rationale: [
      "Wenn SLR 80°+ und Heel Raise links symmetrisch → Wirbelsäule trägt Vollbelastung.",
      "Bench Press, Squat, Kreuzheben jetzt möglich — aber Hip Hinge-Technik beibehalten.",
      "Kalorienüberschuss + hohe Trainingsvolumen für 3+ kg Zunahme in 4 Wochen möglich.",
    ],
    kpis: [
      { label: "Körpergewicht", current: "70 kg", target: "73–75 kg" },
      { label: "Bench Press", current: "—", target: "Volle Belastung" },
      { label: "Heel Raise links (einseitig)", current: "15 Wdh.", target: "3×20 symmetrisch" },
      { label: "Kalorien/Tag", current: "—", target: "TDEE +400 kcal" },
    ],
    exercises: {
      home: [
        { id: "floor-press-h3", name: "Floor Press (Kurzhanteln)", sets: 4, reps: 10, tag: "Brust", priority: "HIGH", youtube: "https://www.youtube.com/watch?v=uUGDRwge4F8", clinical: "Ohne Bench: Floor Press maximiert ROM sicher.", cues: ["Voller ROM", "Exzentrisch 3 Sek.", "Bis Versagen"], progression: "+1–2 kg/Woche" },
        { id: "kb-swing-h3", name: "KB Swing (schwer)", sets: 5, reps: 15, tag: "Posterior Chain", priority: "HIGH", youtube: "https://www.youtube.com/watch?v=YSxHifyI6s8", clinical: "Explosiver Hip Hinge. Gastroc/Glute/Hamstring. Kein Axialschmerz erwartet.", cues: ["Hip Hinge", "Gesäß blockieren", "Explosiv — nicht schwingen"], progression: "Schwereres Kettlebell" },
        { id: "pushup-feet-h3", name: "Push-Up (Füße auf Sofa)", sets: 4, reps: "bis Versagen", tag: "Brust Oberteil", priority: "MEDIUM", youtube: "https://www.youtube.com/watch?v=wQq3ybaLZeA", clinical: "Oberer Pektoralis. Kein Axialrisiko.", cues: ["Körper gerade", "Schulterweite Griffbreite", "Kontrolliert"], progression: "Gewichtsweste" },
        { id: "band-row-h3", name: "Bent-Over Row (Band)", sets: 4, reps: 12, tag: "Rücken", priority: "MEDIUM", youtube: "https://www.youtube.com/watch?v=pYcpY20QaE8", clinical: "Rücken gerade — kein Flexionsrisiko.", cues: ["Hüftgelenk leicht gebeugt", "Ellenbogen nah", "2 Sek. oben"], progression: "Stärkeres Band" },
        { id: "hr-weighted-h3", name: "Heel Raise links (Rucksack)", sets: 5, reps: "bis Versagen", tag: "KPI · S1", isKPI: true, priority: "HIGH", youtube: "https://www.youtube.com/watch?v=LV6cJUMNhJY", clinical: "Progression mit Gewicht. Ziel: Symmetrie zu rechts.", cues: ["Rucksack 5–10 kg", "Nur links", "Wdh. wöchentlich notieren"], progression: "+2,5 kg alle 2 Wochen" },
      ],
      gym: [
        { id: "bench-g3", name: "Bench Press (Langhantel)", sets: 4, reps: 10, tag: "Brust", priority: "HIGH", youtube: "https://www.youtube.com/watch?v=vcBig73ojpE", clinical: "Rückkehr zum Bench. Natürliche Rückenkurve. Fuß flach.", cues: ["Natürliche Rückenkurve", "Füße flach", "3 Sek. senken", "Kein Hohlkreuz erzwingen"], progression: "+2,5 kg alle 2 Wochen" },
        { id: "squat-g3", name: "Back Squat (leicht) oder Goblet", sets: 4, reps: 8, tag: "Beine", priority: "MEDIUM", youtube: "https://www.youtube.com/watch?v=bEv6CCg2BC8", clinical: "Wenn LWS schmerzfrei → vorsichtiger Squat. Alternativ: Goblet oder Hack Squat.", cues: ["Aufrecht halten", "Knie über Zehen", "Bei Rückenschmerz: sofort stoppen → Goblet"], progression: "+5 kg alle 2 Wochen wenn schmerzfrei" },
        { id: "leg-press-g3", name: "Leg Press (Maschine)", sets: 4, reps: 12, tag: "Beine · Volumen", priority: "HIGH", youtube: "https://www.youtube.com/watch?v=IZxyjW7MPJQ", clinical: "Hohes Volumen. Sichere Alternative zu Squat.", cues: ["Rücken flach", "90° Kniewinkel", "Kein Durchstrecken"], progression: "+5 kg alle 2 Wochen" },
        { id: "calf-machine-heavy", name: "Calf Raise links — Belastet", sets: 5, reps: "bis Versagen", tag: "KPI · S1", isKPI: true, priority: "HIGH", youtube: "https://www.youtube.com/watch?v=LV6cJUMNhJY", clinical: "Schwere Belastung. Ziel: Symmetrie zu rechts bis Hochzeit.", cues: ["Maximalgewicht das 10+ Wdh. erlaubt", "Voller ROM", "Wöchentlich steigern"], progression: "Wöchentlich +2,5 kg" },
        { id: "weighted-row-g3", name: "Barbell Row / Cable Row", sets: 4, reps: 10, tag: "Rücken", priority: "MEDIUM", youtube: "https://www.youtube.com/watch?v=pYcpY20QaE8", clinical: "Rücken gerade, kein Runden. Schwere Last möglich wenn LWS stabil.", cues: ["Hip Hinge-Position", "Rücken parallel zum Boden", "Ellenbogen nah"], progression: "+2,5 kg alle 2 Wochen" },
      ],
    },
    nutrition: [
      "Ziel: TDEE + 300–500 kcal/Tag (ca. 2.800–3.000 kcal bei Ran)",
      "Protein: 1,6–2,0 g/kg → 112–140 g/Tag",
      "Quellen: Tofu (15g/100g), Seitan (25g/100g), Tempeh (20g/100g), Edamame, Linsen, Erbsenprotein-Pulver",
      "Kohlenhydrate ums Training: Reis, Süßkartoffel, Haferflocken, Banane",
      "Fette: Avocado, Tahini, Olivenöl, Nussbutter",
      "Praktisch: 2× Protein-Shake/Tag + 3 Hauptmahlzeiten = einfachstes Weg zu 140g",
    ],
  },
  {
    id: 4,
    name: "Fußball & Schweden",
    dateRange: "Juni – Aug 2026",
    startDate: "2026-06-01",
    endDate: "2026-08-07",
    status: "upcoming",
    color: "#ff453a",
    milestone: "07.08.2026",
    milestoneLabel: "Fahrradtour Schweden",
    clinicalNote: "Return-to-Play: Agilität → Richtungswechsel → Plyometrie → Vollkontakt. 6 Monate post-Injury = sicheres Fenster.",
    rationale: [
      "6-Monats-Regel: Anulus fibrosus-Heilung + neurale Adaptation. Sequestered fragment fast vollständig resorbiert.",
      "Fußball vor Schweden: explosive Belastung zuerst, dann Ausdauer.",
      "Fahrrad: niedrige Axialbelastung, hohe Gastroc-Anforderung → perfektes Ziel.",
    ],
    kpis: [
      { label: "SLR", current: "—", target: "85°+ ohne Einschränkung" },
      { label: "Heel Raise links", current: "—", target: "Symmetrisch zu rechts" },
      { label: "Sprint 20m", current: "—", target: "Schmerzfrei" },
      { label: "Radfahren", current: "—", target: "3+ Std. ohne Schmerz" },
    ],
    exercises: {
      home: [
        { id: "lateral-shuffle-h", name: "Lateral Shuffle", sets: 4, reps: "20m ×2", tag: "Agilität", priority: "HIGH", youtube: "https://www.youtube.com/watch?v=NMEqQ5-_-Ts", clinical: "Phase 1 Return-to-Play. Seitliche Bewegung, niedriger Schwerpunkt.", cues: ["Tief bleiben", "Nicht kreuzen", "Tempo steigern"], progression: "Geschwindigkeit wöchentlich erhöhen" },
        { id: "box-jump-h4", name: "Box Jump (Treppenstufe)", sets: 3, reps: 8, tag: "Plyometrie", priority: "HIGH", youtube: "https://www.youtube.com/watch?v=52loww6bIyk", clinical: "Einstieg Plyometrie. Impact-Toleranz aufbauen.", cues: ["Weiche Landung", "Knie gebeugt", "Runtersteigen — nicht springen"], progression: "Höhe erhöhen" },
        { id: "single-leg-hop-h", name: "Single-Leg Hop (links)", sets: 3, reps: 8, tag: "Plyometrie · S1", priority: "HIGH", youtube: "https://www.youtube.com/watch?v=ULEqX7A3jaU", clinical: "Gastroc muss explosiv wirken. Test für Return-to-Sport Clearance.", cues: ["Absprung und Landung links allein", "Weiche Landung", "Kein Rückenschmerz"], progression: "Distanz erhöhen" },
        { id: "cycling-h4", name: "Fahrrad-Intervalle", sets: 5, reps: "3 Min. / 2 Min. Pause", tag: "Ausdauer", priority: "HIGH", youtube: "https://www.youtube.com/watch?v=zDZPpuVLPFY", clinical: "Spezifische Vorbereitung Schweden. VO2max + Sitzdauer.", cues: ["Aufrecht sitzen", "RPE ≤ 8", "+5 Min./Woche progressiv"], progression: "Wöchentlich +5 Min." },
      ],
      gym: [
        { id: "sprint-treadmill", name: "Laufband-Sprints", sets: 6, reps: "20 Sek. / 90 Sek. Pause", tag: "Sprint", priority: "HIGH", youtube: "https://www.youtube.com/watch?v=_kGESn8ArrU", clinical: "Progressiver Sprint-Aufbau. Geschwindigkeit wöchentlich erhöhen.", cues: ["Aufrechte Haltung", "Progressiv steigern", "Schmerzfrei bleiben"], progression: "+0,5 km/h pro Woche" },
        { id: "box-jump-g4", name: "Box Jump (Kasten, 40 cm+)", sets: 4, reps: 8, tag: "Plyometrie", priority: "HIGH", youtube: "https://www.youtube.com/watch?v=52loww6bIyk", clinical: "Höherer Kasten = mehr Impact. Return-to-Sport Standard.", cues: ["Weiche Landung", "Beide Beine", "Armeinsatz"], progression: "Kastenhöhe erhöhen" },
        { id: "agility-ladder", name: "Agility Ladder", sets: 4, reps: "10m ×3", tag: "Agilität", priority: "HIGH", youtube: "https://www.youtube.com/watch?v=GX9AViYxmZI", clinical: "Fußball-spezifische Koordination. Schnelle Fußarbeit.", cues: ["Tief und schnell", "Blick nach vorne", "Arme aktiv"], progression: "Muster wechseln, Tempo erhöhen" },
        { id: "cycling-ergometer", name: "Fahrrad-Ergometer (lang)", sets: 1, reps: "60–120 Min.", tag: "Ausdauer", priority: "HIGH", youtube: "https://www.youtube.com/watch?v=zDZPpuVLPFY", clinical: "Sitzausdauer für Schweden. Sattelposition überprüfen.", cues: ["Aufrechte Haltung", "RPE 6–7 Dauerbelastung", "Alle 30 Min. kurz aufstehen"], progression: "+15 Min./Woche" },
      ],
    },
  },
];

// ── SYMPTOM DASHBOARD ─────────────────────────────────────────────────────────

const SYMPTOM_QUESTIONS = [
  { id: "pain", label: "Schmerz heute", min: 0, max: 10, unit: "VAS", warn: 4, critical: 7 },
  { id: "steps", label: "Schritte gestern", min: 0, max: 15000, unit: "Schritte", warn: 9000, critical: 12000 },
  { id: "limp", label: "Hinken", options: ["Kein", "Leicht", "Deutlich"], warn: 2 },
  { id: "radiation", label: "Ausstrahlung ins Bein", options: ["Keine", "Leicht", "Stark"], warn: 2, critical: 3 },
];

function SymptomDashboard() {
  const [values, setValues] = useState({ pain: 2, steps: 3000, limp: 0, radiation: 0 });
  const [submitted, setSubmitted] = useState(false);

  const getWarning = () => {
    const warnings = [];
    if (values.pain >= 7) warnings.push("⚠️ Hoher Schmerz — Belastung reduzieren. Arzt kontaktieren wenn >7 anhält.");
    if (values.pain >= 4 && values.pain < 7) warnings.push("🔶 Mäßiger Schmerz — Training anpassen. Nerve Flossing vor dem Training.");
    if (values.steps >= 10000) warnings.push("🔶 Viele Schritte — Erholungstag empfohlen wie gestern.");
    if (values.radiation >= 2) warnings.push("⚠️ Starke Ausstrahlung — kein Training heute. Arzt informieren.");
    if (values.radiation === 1) warnings.push("🔶 Leichte Ausstrahlung — Nerve Flossing, Intensität reduzieren.");
    if (warnings.length === 0) warnings.push("✅ Grünes Licht — Training wie geplant.");
    return warnings;
  };

  const trafficLight = values.pain >= 7 || values.radiation >= 2 ? "red"
    : values.pain >= 4 || values.steps >= 9000 || values.radiation === 1 ? "yellow"
    : "green";

  const lightColor = { red: "#ff453a", yellow: "#ffd60a", green: "#34c759" }[trafficLight];

  return (
    <div>
      <div style={{ color: "rgba(255,255,255,0.2)", fontSize: 10, fontWeight: 700, textTransform: "uppercase", letterSpacing: 1.5, marginBottom: 16 }}>
        Tägliches Symptom-Check
      </div>

      {/* Pain slider */}
      <div style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: 16, padding: "16px 18px", marginBottom: 10 }}>
        <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 12 }}>
          <span style={{ color: "rgba(255,255,255,0.55)", fontSize: 14 }}>Schmerz (VAS)</span>
          <span style={{ color: values.pain >= 7 ? "#ff453a" : values.pain >= 4 ? "#ffd60a" : "#34c759", fontWeight: 800, fontSize: 22 }}>{values.pain}</span>
        </div>
        <input type="range" min="0" max="10" value={values.pain}
          onChange={e => setValues(v => ({ ...v, pain: parseInt(e.target.value) }))}
          style={{ width: "100%", accentColor: values.pain >= 7 ? "#ff453a" : values.pain >= 4 ? "#ffd60a" : "#34c759" }}
        />
        <div style={{ display: "flex", justifyContent: "space-between", marginTop: 4 }}>
          <span style={{ color: "rgba(255,255,255,0.22)", fontSize: 11 }}>Kein</span>
          <span style={{ color: "rgba(255,255,255,0.22)", fontSize: 11 }}>Unerträglich</span>
        </div>
      </div>

      {/* Steps slider */}
      <div style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: 16, padding: "16px 18px", marginBottom: 10 }}>
        <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 12 }}>
          <span style={{ color: "rgba(255,255,255,0.55)", fontSize: 14 }}>Schritte gestern</span>
          <span style={{ color: values.steps >= 10000 ? "#ffd60a" : "#34c759", fontWeight: 800, fontSize: 22 }}>{values.steps.toLocaleString()}</span>
        </div>
        <input type="range" min="0" max="15000" step="500" value={values.steps}
          onChange={e => setValues(v => ({ ...v, steps: parseInt(e.target.value) }))}
          style={{ width: "100%", accentColor: values.steps >= 10000 ? "#ffd60a" : "#34c759" }}
        />
      </div>

      {/* Limp + Radiation */}
      {[
        { id: "limp", label: "Hinken", opts: ["Kein ✓", "Leicht", "Deutlich"] },
        { id: "radiation", label: "Ausstrahlung ins Bein", opts: ["Keine ✓", "Leicht", "Stark ⚠️"] },
      ].map(q => (
        <div key={q.id} style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: 16, padding: "16px 18px", marginBottom: 10 }}>
          <div style={{ color: "rgba(255,255,255,0.55)", fontSize: 14, marginBottom: 12 }}>{q.label}</div>
          <div style={{ display: "flex", gap: 8 }}>
            {q.opts.map((opt, i) => (
              <button key={i} onClick={() => setValues(v => ({ ...v, [q.id]: i }))} style={{
                flex: 1, padding: "10px 4px", borderRadius: 12,
                border: `1.5px solid ${values[q.id] === i ? (i === 0 ? "#34c759" : i === 1 ? "#ffd60a" : "#ff453a") : "rgba(255,255,255,0.08)"}`,
                background: values[q.id] === i ? (i === 0 ? "#34c75920" : i === 1 ? "#ffd60a20" : "#ff453a20") : "transparent",
                color: values[q.id] === i ? (i === 0 ? "#34c759" : i === 1 ? "#ffd60a" : "#ff453a") : "rgba(255,255,255,0.3)",
                fontSize: 12, fontWeight: 600, cursor: "pointer", fontFamily: "inherit", transition: "all 0.2s",
              }}>{opt}</button>
            ))}
          </div>
        </div>
      ))}

      {/* Traffic light result */}
      <div style={{
        background: lightColor + "15",
        border: `1px solid ${lightColor}40`,
        borderRadius: 16, padding: "18px 20px", marginTop: 4,
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 12 }}>
          <div style={{ width: 14, height: 14, borderRadius: "50%", background: lightColor, boxShadow: `0 0 12px ${lightColor}` }} />
          <span style={{ color: lightColor, fontWeight: 700, fontSize: 15 }}>
            {trafficLight === "green" ? "Training freigegeben" : trafficLight === "yellow" ? "Angepasstes Training" : "Kein Training heute"}
          </span>
        </div>
        {getWarning().map((w, i) => (
          <div key={i} style={{ color: "rgba(255,255,255,0.6)", fontSize: 13, lineHeight: 1.6, marginBottom: 4 }}>{w}</div>
        ))}
      </div>
    </div>
  );
}

// ── SVG MACRO PROGRESS ────────────────────────────────────────────────────────

function MacroProgress({ animated }) {
  const [progress, setProgress] = useState(0);
  const [hovered, setHovered] = useState(null);

  useEffect(() => {
    if (!animated) return;
    let start = null;
    const dur = 2000;
    const tick = (ts) => {
      if (!start) start = ts;
      const p = Math.min((ts - start) / dur, 1);
      setProgress(1 - Math.pow(1 - p, 4));
      if (p < 1) requestAnimationFrame(tick);
    };
    requestAnimationFrame(tick);
  }, [animated]);

  const W = 360, H = 300, cx = W / 2, cy = H / 2 + 10;
  const R1 = 125, R2 = 82;
  const startA = -200, totalA = 220;
  const tStart = new Date("2026-01-09"), tEnd = swedenDate;
  const tTotal = tEnd - tStart;

  const dateToA = (d) => startA + Math.max(0, Math.min(1, (d - tStart) / tTotal)) * totalA;
  const polar = (a, r) => {
    const rad = a * Math.PI / 180;
    return { x: cx + r * Math.cos(rad), y: cy + r * Math.sin(rad) };
  };
  const arc = (a1, a2, r1, r2) => {
    const p1 = polar(a1, r1), p2 = polar(a2, r1), p3 = polar(a2, r2), p4 = polar(a1, r2);
    const lg = a2 - a1 > 180 ? 1 : 0;
    return `M${p1.x},${p1.y} A${r1},${r1},0,${lg},1,${p2.x},${p2.y} L${p3.x},${p3.y} A${r2},${r2},0,${lg},0,${p4.x},${p4.y}Z`;
  };

  const curA = startA + (progressPercent / 100) * totalA * progress;
  const todayXY = polar(curA, (R1 + R2) / 2);

  return (
    <div>
      <svg width="100%" viewBox={`0 0 ${W} ${H}`} style={{ overflow: "visible" }}>
        <defs>
          <filter id="glow2">
            <feGaussianBlur stdDeviation="4" result="blur" />
            <feMerge><feMergeNode in="blur" /><feMergeNode in="SourceGraphic" /></feMerge>
          </filter>
          <filter id="softglow2">
            <feGaussianBlur stdDeviation="8" result="blur" />
            <feMerge><feMergeNode in="blur" /><feMergeNode in="SourceGraphic" /></feMerge>
          </filter>
        </defs>

        {/* Track */}
        <path d={arc(startA, startA + totalA, R1, R2)} fill="rgba(255,255,255,0.03)" stroke="rgba(255,255,255,0.06)" strokeWidth="0.5" />

        {/* Phase arcs */}
        {PHASES.map((p, i) => {
          const a1 = dateToA(new Date(p.startDate));
          const a2 = dateToA(new Date(p.endDate));
          return (
            <path key={i} d={arc(a1, a2 - 0.5, R1, R2)}
              fill={p.color}
              opacity={hovered === i ? 0.9 : 0.45}
              stroke={p.color} strokeWidth="0.5"
              style={{ cursor: "pointer", transition: "opacity 0.2s" }}
              onMouseEnter={() => setHovered(i)}
              onMouseLeave={() => setHovered(null)}
            />
          );
        })}

        {/* Milestone ticks */}
        {MILESTONES.map((m, i) => {
          const a = dateToA(new Date(m.fullDate));
          const o = polar(a, R1 + 10), inn = polar(a, R2 - 10), mid = polar(a, (R1 + R2) / 2);
          return (
            <g key={i}>
              <line x1={inn.x} y1={inn.y} x2={o.x} y2={o.y} stroke={m.color} strokeWidth="1" strokeDasharray="2,2" opacity="0.6" />
              <circle cx={mid.x} cy={mid.y} r="5" fill={m.color} filter="url(#glow2)" />
              <circle cx={mid.x} cy={mid.y} r="2.5" fill="#000" />
            </g>
          );
        })}

        {/* Today */}
        {progress > 0.01 && (
          <g filter="url(#softglow2)">
            <circle cx={todayXY.x} cy={todayXY.y} r="16" fill="rgba(255,255,255,0.06)" />
            <circle cx={todayXY.x} cy={todayXY.y} r="9" fill="#fff" />
            <circle cx={todayXY.x} cy={todayXY.y} r="4.5" fill="#0a84ff" />
          </g>
        )}

        {/* Center */}
        <text x={cx} y={cy - 24} textAnchor="middle" fill="rgba(255,255,255,0.28)" fontSize="10" fontFamily="-apple-system,sans-serif" letterSpacing="2">TAG</text>
        <text x={cx} y={cy + 16} textAnchor="middle" fill="white" fontSize="50" fontWeight="800" fontFamily="-apple-system,sans-serif">{daysSinceInjury}</text>
        <text x={cx} y={cy + 37} textAnchor="middle" fill="rgba(255,255,255,0.3)" fontSize="13" fontFamily="-apple-system,sans-serif">Woche {weeksSinceInjury} · {progressPercent}%</text>

        {(() => {
          const sp = polar(startA, R1 + 18), ep = polar(startA + totalA, R1 + 18);
          return (
            <>
              <text x={sp.x} y={sp.y} textAnchor="middle" fill="rgba(255,255,255,0.22)" fontSize="9" fontFamily="-apple-system,sans-serif">9. Jan</text>
              <text x={ep.x} y={ep.y} textAnchor="middle" fill="rgba(255,255,255,0.22)" fontSize="9" fontFamily="-apple-system,sans-serif">7. Aug</text>
            </>
          );
        })()}
      </svg>

      {/* Phase hover info */}
      <div style={{ minHeight: 48, marginBottom: 12 }}>
        {hovered !== null && (
          <div style={{ background: PHASES[hovered].color + "15", border: `1px solid ${PHASES[hovered].color}30`, borderRadius: 14, padding: "12px 16px", textAlign: "center" }}>
            <div style={{ color: PHASES[hovered].color, fontWeight: 700, fontSize: 14 }}>{PHASES[hovered].name}</div>
            <div style={{ color: "rgba(255,255,255,0.45)", fontSize: 12 }}>{PHASES[hovered].dateRange}</div>
          </div>
        )}
      </div>

      <div style={{ display: "flex", flexWrap: "wrap", gap: 7, justifyContent: "center", marginBottom: 14 }}>
        {PHASES.map((p, i) => (
          <div key={i} style={{ display: "flex", alignItems: "center", gap: 5, padding: "5px 12px", borderRadius: 20, background: hovered === i ? p.color + "20" : "rgba(255,255,255,0.04)", border: `1px solid ${hovered === i ? p.color + "50" : "rgba(255,255,255,0.06)"}`, cursor: "pointer", transition: "all 0.2s" }}
            onMouseEnter={() => setHovered(i)} onMouseLeave={() => setHovered(null)}>
            <div style={{ width: 7, height: 7, borderRadius: "50%", background: p.color }} />
            <span style={{ color: "rgba(255,255,255,0.45)", fontSize: 11 }}>{p.dateRange}</span>
          </div>
        ))}
      </div>

      <div style={{ display: "flex", flexWrap: "wrap", gap: 7, justifyContent: "center" }}>
        {MILESTONES.map((m, i) => (
          <div key={i} style={{ display: "flex", alignItems: "center", gap: 5 }}>
            <div style={{ width: 6, height: 6, borderRadius: "50%", background: m.color }} />
            <span style={{ color: "rgba(255,255,255,0.35)", fontSize: 11 }}>{m.date} {m.label}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

// ── EXERCISE CARD ─────────────────────────────────────────────────────────────

function ExerciseCard({ ex, color }) {
  const [open, setOpen] = useState(false);
  const [doneSets, setDoneSets] = useState(0);
  const totalSets = typeof ex.sets === "number" ? ex.sets : 4;
  const pct = doneSets / totalSets;

  const priorityColor = { HIGH: color, MEDIUM: "rgba(255,255,255,0.4)", LOW: "rgba(255,255,255,0.2)" };

  return (
    <div style={{
      background: open ? "rgba(255,255,255,0.05)" : "rgba(255,255,255,0.03)",
      border: `1px solid ${open ? color + "50" : ex.priority === "HIGH" ? color + "20" : "rgba(255,255,255,0.07)"}`,
      borderRadius: 18, overflow: "hidden", marginBottom: 10, transition: "all 0.25s",
    }}>
      <div style={{ padding: "16px 18px 12px", cursor: "pointer" }} onClick={() => setOpen(!open)}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
          <div style={{ flex: 1 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 7, marginBottom: 7, flexWrap: "wrap" }}>
              {ex.priority === "HIGH" && <div style={{ width: 5, height: 5, borderRadius: "50%", background: color, flexShrink: 0, marginTop: 1 }} />}
              <span style={{ color: "#fff", fontWeight: 700, fontSize: 15 }}>{ex.name}</span>
              {ex.isKPI && <span style={{ background: color + "30", color, fontSize: 10, padding: "2px 8px", borderRadius: 20, fontWeight: 700 }}>KPI</span>}
              {ex.tag && <span style={{ background: "rgba(255,255,255,0.06)", color: "rgba(255,255,255,0.35)", fontSize: 10, padding: "2px 8px", borderRadius: 20 }}>{ex.tag}</span>}
            </div>
            <span style={{ color: "rgba(255,255,255,0.28)", fontSize: 13 }}>{ex.sets} Sätze × {ex.reps} Wdh.</span>
          </div>
          <svg width="20" height="20" viewBox="0 0 20 20" fill="none" style={{ transform: open ? "rotate(180deg)" : "none", transition: "transform 0.3s", flexShrink: 0 }}>
            <path d="M5 7.5L10 12.5L15 7.5" stroke="rgba(255,255,255,0.2)" strokeWidth="1.5" strokeLinecap="round" />
          </svg>
        </div>
        <div style={{ height: 3, background: "rgba(255,255,255,0.05)", borderRadius: 2, marginTop: 12 }}>
          <div style={{ height: "100%", width: `${pct * 100}%`, background: color, borderRadius: 2, transition: "width 0.3s" }} />
        </div>
      </div>

      {open && (
        <div style={{ borderTop: "1px solid rgba(255,255,255,0.06)", padding: "16px 18px 20px" }}>
          {/* Clinical rationale */}
          {ex.clinical && (
            <div style={{ borderLeft: `2px solid ${color}`, paddingLeft: 12, marginBottom: 16 }}>
              <span style={{ color: "rgba(255,255,255,0.38)", fontSize: 12, lineHeight: 1.6 }}>{ex.clinical}</span>
            </div>
          )}

          <div style={{ marginBottom: 16 }}>
            {ex.cues.map((c, i) => (
              <div key={i} style={{ display: "flex", gap: 8, marginBottom: 7 }}>
                <span style={{ color, fontSize: 10, marginTop: 4, flexShrink: 0 }}>▸</span>
                <span style={{ color: "rgba(255,255,255,0.65)", fontSize: 13, lineHeight: 1.5 }}>{c}</span>
              </div>
            ))}
          </div>

          {ex.progression && (
            <div style={{ background: color + "10", borderRadius: 10, padding: "10px 14px", marginBottom: 16 }}>
              <span style={{ color: "rgba(255,255,255,0.25)", fontSize: 10, textTransform: "uppercase", letterSpacing: 1 }}>Progression → </span>
              <span style={{ color: color, fontSize: 12, fontWeight: 600 }}>{ex.progression}</span>
            </div>
          )}

          <div style={{ display: "flex", gap: 10, alignItems: "center", marginBottom: 14 }}>
            <button onClick={() => { if (doneSets < totalSets) setDoneSets(doneSets + 1); else setDoneSets(0); }} style={{
              flex: 1, padding: "15px", borderRadius: 16,
              border: `1.5px solid ${doneSets === totalSets ? color : "rgba(255,255,255,0.1)"}`,
              background: doneSets === totalSets ? color + "20" : color + "10",
              color: doneSets === totalSets ? color : "#fff",
              fontWeight: 700, fontSize: 15, cursor: "pointer", fontFamily: "inherit", transition: "all 0.2s",
            }}>
              {doneSets === totalSets ? "✓ Alle Sätze!" : doneSets === 0 ? "Satz starten" : `Satz ${doneSets + 1} von ${totalSets}`}
            </button>
            <div style={{ display: "flex", gap: 5 }}>
              {Array(totalSets).fill(0).map((_, i) => (
                <div key={i} onClick={() => setDoneSets(i < doneSets ? i : i + 1)} style={{
                  width: 28, height: 28, borderRadius: 8,
                  background: i < doneSets ? color + "25" : "rgba(255,255,255,0.05)",
                  border: `1.5px solid ${i < doneSets ? color : "rgba(255,255,255,0.08)"}`,
                  cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", transition: "all 0.2s",
                }}>
                  {i < doneSets && <span style={{ color, fontSize: 11 }}>✓</span>}
                </div>
              ))}
            </div>
          </div>

          <a href={ex.youtube} target="_blank" rel="noopener noreferrer" style={{
            display: "flex", alignItems: "center", gap: 10, padding: "11px 16px",
            background: "rgba(255,0,0,0.07)", border: "1px solid rgba(255,0,0,0.18)",
            borderRadius: 12, textDecoration: "none",
          }}>
            <svg width="20" height="14" viewBox="0 0 20 14" fill="none">
              <rect width="20" height="14" rx="3" fill="#FF0000" />
              <path d="M8 4L14 7L8 10V4Z" fill="white" />
            </svg>
            <span style={{ color: "rgba(255,255,255,0.55)", fontSize: 13 }}>Übung auf YouTube ansehen</span>
          </a>
        </div>
      )}
    </div>
  );
}

// ── MAIN APP ──────────────────────────────────────────────────────────────────

export default function App() {
  const [view, setView] = useState("overview");
  const [activePhase, setActivePhase] = useState(PHASES[0]);
  const [gymMode, setGymMode] = useState({});
  const [loaded, setLoaded] = useState(false);
  const [progressAnimated, setProgressAnimated] = useState(false);

  useEffect(() => { setTimeout(() => setLoaded(true), 80); }, []);
  useEffect(() => { if (view === "progress") setTimeout(() => setProgressAnimated(true), 150); }, [view]);

  const isGym = gymMode[activePhase.id] || false;
  const exercises = activePhase.exercises[isGym ? "gym" : "home"];

  const TABS = [
    { id: "overview", label: "Übersicht" },
    { id: "train", label: "Training" },
    { id: "symptom", label: "Check-in" },
    { id: "progress", label: "Fortschritt" },
  ];

  return (
    <div style={{ minHeight: "100vh", background: "#000", fontFamily: "-apple-system,'Helvetica Neue',sans-serif", color: "#fff", maxWidth: 430, margin: "0 auto", paddingBottom: 90 }}>

      {/* HEADER */}
      <div style={{ padding: "52px 24px 24px", opacity: loaded ? 1 : 0, transform: loaded ? "none" : "translateY(10px)", transition: "opacity 0.5s,transform 0.5s" }}>
        <div style={{ color: "rgba(255,255,255,0.25)", fontSize: 11, letterSpacing: 2, textTransform: "uppercase", marginBottom: 6 }}>Rehabilitation · L5/S1 · S1-Radikulopathie</div>
        <div style={{ fontSize: 34, fontWeight: 800, letterSpacing: -0.5, marginBottom: 2 }}>Tag {daysSinceInjury}</div>
        <div style={{ color: "rgba(255,255,255,0.28)", fontSize: 14, marginBottom: 26 }}>Woche {weeksSinceInjury} · seit 9. Januar 2026</div>

        <div style={{ marginBottom: 22 }}>
          <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 10 }}>
            <span style={{ color: "rgba(255,255,255,0.35)", fontSize: 13 }}>Bis Schweden</span>
            <span style={{ color: "#ffd60a", fontWeight: 700, fontSize: 14 }}>{progressPercent}%</span>
          </div>
          <div style={{ height: 6, background: "rgba(255,255,255,0.06)", borderRadius: 3, overflow: "hidden", position: "relative" }}>
            {PHASES.map((p, i) => {
              const ps = Math.max(0, (new Date(p.startDate) - new Date("2026-01-09")) / (totalDays * 1000 * 60 * 60 * 24) * 100);
              const pe = Math.min(100, (new Date(p.endDate) - new Date("2026-01-09")) / (totalDays * 1000 * 60 * 60 * 24) * 100);
              return <div key={i} style={{ position: "absolute", top: 0, bottom: 0, left: `${ps}%`, width: `${pe - ps}%`, background: p.color, opacity: 0.2 }} />;
            })}
            <div style={{ position: "relative", zIndex: 1, height: "100%", width: loaded ? `${progressPercent}%` : "0%", background: `linear-gradient(90deg,${PHASE_COLORS.join(",")})`, borderRadius: 3, transition: "width 1.4s cubic-bezier(0.16,1,0.3,1)" }} />
          </div>
        </div>

        <div style={{ display: "flex", gap: 8, overflowX: "auto", paddingBottom: 2 }}>
          {MILESTONES.map(m => (
            <div key={m.date} style={{ flexShrink: 0, background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: 14, padding: "10px 14px", minWidth: 80 }}>
              <div style={{ color: m.color, fontSize: 11, fontWeight: 700, marginBottom: 3 }}>{m.date}</div>
              <div style={{ color: "rgba(255,255,255,0.48)", fontSize: 11, marginBottom: 4 }}>{m.label}</div>
              <div style={{ color: "rgba(255,255,255,0.2)", fontSize: 10 }}>{daysUntil(m.fullDate)} Tage</div>
            </div>
          ))}
        </div>
      </div>

      {/* NAV */}
      <div style={{ display: "flex", borderBottom: "1px solid rgba(255,255,255,0.07)", position: "sticky", top: 0, zIndex: 10, background: "rgba(0,0,0,0.9)", backdropFilter: "blur(20px)" }}>
        {TABS.map(tab => (
          <button key={tab.id} onClick={() => setView(tab.id)} style={{
            flex: 1, padding: "14px 4px", background: "transparent", border: "none",
            borderBottom: `2px solid ${view === tab.id ? "#0a84ff" : "transparent"}`,
            color: view === tab.id ? "#0a84ff" : "rgba(255,255,255,0.28)",
            fontWeight: 600, fontSize: 12, cursor: "pointer", transition: "all 0.2s", fontFamily: "inherit",
          }}>{tab.label}</button>
        ))}
      </div>

      <div style={{ padding: "24px" }}>

        {/* ÜBERSICHT */}
        {view === "overview" && (
          <div>
            <div style={{ background: "rgba(10,132,255,0.08)", border: "1px solid rgba(10,132,255,0.2)", borderRadius: 20, padding: "20px", marginBottom: 24 }}>
              <div style={{ color: "#0a84ff", fontSize: 11, fontWeight: 700, textTransform: "uppercase", letterSpacing: 1.5, marginBottom: 16 }}>Klinischer Status · Woche {weeksSinceInjury}</div>
              {[
                { k: "SLR", v: "50°", sub: "Ziel: 70°" },
                { k: "Heel Raise links", v: "Höhe 50%, Versagen 3–4 Wdh.", sub: "Reine Muskelschwäche S1" },
                { k: "Schmerz", v: "Kontrolliert", sub: "Pregabalin 2×/Tag" },
                { k: "Gangbild", v: "Leichtes Hinken", sub: "Gastroc/Soleus links schwach" },
              ].map((s, i, arr) => (
                <div key={i} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "11px 0", borderBottom: i < arr.length - 1 ? "1px solid rgba(255,255,255,0.06)" : "none" }}>
                  <span style={{ color: "rgba(255,255,255,0.38)", fontSize: 13 }}>{s.k}</span>
                  <div style={{ textAlign: "right" }}>
                    <div style={{ color: "#fff", fontWeight: 700, fontSize: 14 }}>{s.v}</div>
                    <div style={{ color: "rgba(255,255,255,0.25)", fontSize: 11 }}>{s.sub}</div>
                  </div>
                </div>
              ))}
            </div>

            <div style={{ color: "rgba(255,255,255,0.2)", fontSize: 10, fontWeight: 700, textTransform: "uppercase", letterSpacing: 1.5, marginBottom: 14 }}>Rehab-Phasen</div>
            {PHASES.map(phase => (
              <div key={phase.id} onClick={() => { setActivePhase(phase); setView("train"); }} style={{ background: phase.status === "current" ? `${phase.color}0d` : "rgba(255,255,255,0.03)", border: `1px solid ${phase.status === "current" ? phase.color + "40" : "rgba(255,255,255,0.07)"}`, borderRadius: 20, padding: "18px 20px", cursor: "pointer", marginBottom: 10, position: "relative", overflow: "hidden", transition: "all 0.2s" }}>
                {phase.status === "current" && <div style={{ position: "absolute", top: 0, right: 0, left: 0, height: 2, background: `linear-gradient(90deg,${phase.color},transparent)` }} />}
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                  <div>
                    <div style={{ color: phase.color, fontSize: 11, fontWeight: 700, textTransform: "uppercase", letterSpacing: 1.5, marginBottom: 5 }}>{phase.dateRange}</div>
                    <div style={{ color: "#fff", fontWeight: 700, fontSize: 17, marginBottom: phase.milestoneLabel ? 4 : 0 }}>{phase.name}</div>
                    {phase.milestoneLabel && <div style={{ color: "rgba(255,255,255,0.32)", fontSize: 12 }}>🎯 {phase.milestoneLabel}</div>}
                  </div>
                  <div style={{ background: phase.status === "current" ? phase.color + "25" : "rgba(255,255,255,0.06)", color: phase.status === "current" ? phase.color : "rgba(255,255,255,0.2)", fontSize: 11, fontWeight: 700, padding: "5px 12px", borderRadius: 20 }}>
                    {phase.status === "current" ? "Aktuell" : "Bald"}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* TRAINING */}
        {view === "train" && (
          <div>
            <div style={{ display: "flex", gap: 8, overflowX: "auto", paddingBottom: 4, marginBottom: 18 }}>
              {PHASES.map(p => (
                <button key={p.id} onClick={() => setActivePhase(p)} style={{ flexShrink: 0, padding: "8px 15px", borderRadius: 22, border: `1px solid ${activePhase.id === p.id ? p.color : "rgba(255,255,255,0.09)"}`, background: activePhase.id === p.id ? p.color + "20" : "transparent", color: activePhase.id === p.id ? p.color : "rgba(255,255,255,0.28)", fontSize: 12, fontWeight: 700, cursor: "pointer", fontFamily: "inherit", whiteSpace: "nowrap", transition: "all 0.2s" }}>{p.name}</button>
              ))}
            </div>

            <div style={{ display: "flex", background: "rgba(255,255,255,0.05)", borderRadius: 14, padding: 4, marginBottom: 18 }}>
              {["home", "gym"].map(mode => (
                <button key={mode} onClick={() => setGymMode(prev => ({ ...prev, [activePhase.id]: mode === "gym" }))} style={{ flex: 1, padding: "10px", borderRadius: 11, background: (mode === "gym") === isGym ? "rgba(255,255,255,0.1)" : "transparent", border: "none", color: (mode === "gym") === isGym ? "#fff" : "rgba(255,255,255,0.32)", fontWeight: 700, fontSize: 14, cursor: "pointer", fontFamily: "inherit", transition: "all 0.2s" }}>
                  {mode === "home" ? "🏠 Zuhause" : "🏋️ Fitnessstudio"}
                </button>
              ))}
            </div>

            {activePhase.milestoneLabel && (
              <div style={{ background: activePhase.color + "10", border: `1px solid ${activePhase.color}28`, borderRadius: 16, padding: "13px 18px", marginBottom: 16, display: "flex", alignItems: "center", gap: 12 }}>
                <div>
                  <div style={{ color: activePhase.color, fontSize: 12, fontWeight: 700 }}>{activePhase.milestone}</div>
                  <div style={{ color: "rgba(255,255,255,0.62)", fontSize: 13 }}>{activePhase.milestoneLabel}</div>
                </div>
                <div style={{ marginLeft: "auto", color: "rgba(255,255,255,0.2)", fontSize: 12 }}>{daysUntil(activePhase.milestone)} Tage</div>
              </div>
            )}

            <div style={{ borderLeft: `2px solid ${activePhase.color}`, paddingLeft: 14, marginBottom: 20 }}>
              <span style={{ color: "rgba(255,255,255,0.32)", fontSize: 13, lineHeight: 1.6 }}>{activePhase.clinicalNote}</span>
            </div>

            {activePhase.rationale && (
              <div style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.06)", borderRadius: 16, padding: "16px 18px", marginBottom: 20 }}>
                <div style={{ color: "rgba(255,255,255,0.2)", fontSize: 10, fontWeight: 700, textTransform: "uppercase", letterSpacing: 1.5, marginBottom: 12 }}>Klinische Begründung</div>
                {activePhase.rationale.map((r, i) => (
                  <div key={i} style={{ display: "flex", gap: 8, marginBottom: 8 }}>
                    <span style={{ color: activePhase.color, fontSize: 10, marginTop: 4, flexShrink: 0 }}>▸</span>
                    <span style={{ color: "rgba(255,255,255,0.45)", fontSize: 12, lineHeight: 1.6 }}>{r}</span>
                  </div>
                ))}
              </div>
            )}

            <div style={{ color: "rgba(255,255,255,0.2)", fontSize: 10, fontWeight: 700, textTransform: "uppercase", letterSpacing: 1.5, marginBottom: 12 }}>KPIs</div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8, marginBottom: 24 }}>
              {activePhase.kpis.map((k, i) => (
                <div key={i} style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.06)", borderRadius: 14, padding: "13px 14px" }}>
                  <div style={{ color: "rgba(255,255,255,0.25)", fontSize: 10, textTransform: "uppercase", letterSpacing: 1, marginBottom: 7 }}>{k.label}</div>
                  <div style={{ color: "rgba(255,255,255,0.4)", fontSize: 12, marginBottom: 5 }}>{k.current}</div>
                  <div style={{ display: "flex", alignItems: "center", gap: 4 }}>
                    <span style={{ color: "rgba(255,255,255,0.18)", fontSize: 10 }}>→</span>
                    <span style={{ color: activePhase.color, fontSize: 13, fontWeight: 700 }}>{k.target}</span>
                  </div>
                </div>
              ))}
            </div>

            <div style={{ color: "rgba(255,255,255,0.2)", fontSize: 10, fontWeight: 700, textTransform: "uppercase", letterSpacing: 1.5, marginBottom: 14 }}>
              {exercises.length} Übungen · {isGym ? "Fitnessstudio" : "Zuhause"} · 🔵 = Priorität
            </div>
            {exercises.map(ex => <ExerciseCard key={ex.id} ex={ex} color={activePhase.color} />)}

            {activePhase.nutrition && (
              <div style={{ marginTop: 10 }}>
                <div style={{ color: "rgba(255,255,255,0.2)", fontSize: 10, fontWeight: 700, textTransform: "uppercase", letterSpacing: 1.5, marginBottom: 14 }}>Ernährung</div>
                <div style={{ background: "rgba(255,255,255,0.03)", border: `1px solid ${activePhase.color}20`, borderRadius: 18, padding: "18px 20px" }}>
                  {activePhase.nutrition.map((item, i) => (
                    <div key={i} style={{ display: "flex", gap: 10, marginBottom: 10 }}>
                      <span style={{ color: activePhase.color, fontSize: 10, marginTop: 4, flexShrink: 0 }}>▸</span>
                      <span style={{ color: "rgba(255,255,255,0.55)", fontSize: 13, lineHeight: 1.5 }}>{item}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* SYMPTOM CHECK-IN */}
        {view === "symptom" && <SymptomDashboard />}

        {/* FORTSCHRITT */}
        {view === "progress" && (
          <div>
            <div style={{ color: "rgba(255,255,255,0.2)", fontSize: 10, fontWeight: 700, textTransform: "uppercase", letterSpacing: 1.5, marginBottom: 20 }}>Makro-Fortschritt</div>
            <MacroProgress animated={progressAnimated} />
          </div>
        )}
      </div>
    </div>
  );
}
